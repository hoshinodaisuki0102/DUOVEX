#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace DualSync.Editor
{
    // Safe opt-in cleanup: the audit is read-only; removal backs up every old
    // PNG + .meta outside Assets and skips files referenced from serialized Unity assets.
    public static class DuovexLegacyCleanup
    {
        static readonly string[] Candidates = {
            "Assets/Resources/Visual082/BgMain.png",
            "Assets/Resources/Visual082/BtnPurple.png",
            "Assets/Resources/Visual082/CardIdle.png",
            "Assets/Resources/Visual082/CardSelected.png",
            "Assets/Resources/Visual082/CircleLogo.png",
            "Assets/Resources/Visual082/InfoWhite.png",
            "Assets/Resources/Visual082/SmallPlate.png",
            "Assets/Resources/Visual082/Cover0.png",
            "Assets/Resources/Visual082/Cover1.png",
            "Assets/Resources/Visual082/Cover2.png",
            "Assets/Resources/Visual082/Cover3.png",
            "Assets/Resources/Visual082/Cover4.png",
            "Assets/Resources/Visual082/Cover5.png",
            "Assets/Resources/Visual082/Cover6.png",
            "Assets/Resources/Visual082/Cover7.png",
            "Assets/Resources/Visual082/Cover8.png",
            "Assets/Resources/Visual082/Cover9.png",
            "Assets/Resources/Visual082/Cover10.png",
            "Assets/Resources/Visual082/Cover11.png",
            "Assets/Resources/Visual082/Cover12.png",
            "Assets/Resources/Visual083/ActionActive83.png",
            "Assets/Resources/Visual083/BgMain83.png",
            "Assets/Resources/Visual083/Emblem83.png",
            "Assets/Resources/Visual086/MenuRail86.png",
            "Assets/Resources/Visual086/Monogram86.png",
            "Assets/Resources/Visual086/SignatureLogo86.png"
        };

        static HashSet<string> ReferencedAssets()
        {
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var extensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
                ".unity", ".prefab", ".asset", ".mat", ".controller", ".anim", ".playable", ".overrideController"
            };
            foreach(var path in AssetDatabase.GetAllAssetPaths())
            {
                if(!path.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)) continue;
                if(!extensions.Contains(Path.GetExtension(path))) continue;
                foreach(var dep in AssetDatabase.GetDependencies(path, true))
                    used.Add(dep);
            }
            return used;
        }

        [MenuItem("Tools/Duovex/Audit Unused Legacy UI (No Changes)")]
        public static void Audit()
        {
            var referenced=ReferencedAssets();
            int missing=0, safe=0, blocked=0;
            foreach(var asset in Candidates)
            {
                if(AssetDatabase.LoadMainAssetAtPath(asset)==null) {missing++; continue;}
                if(referenced.Contains(asset)) {blocked++; Debug.LogWarning("[DUOVEX] KEEP: referenced by saved scene/prefab/asset: "+asset);}
                else {safe++; Debug.Log("[DUOVEX] Candidate for cleanup: "+asset);}
            }
            EditorUtility.DisplayDialog("DUOVEX Asset Audit", "Safe candidates: "+safe+"\nReferenced (skipped): "+blocked+"\nAlready absent: "+missing+"\n\nSee Console for paths. No files were changed.", "OK");
        }

        [MenuItem("Tools/Duovex/Back Up and Remove Unused Legacy UI...")]
        public static void Clean()
        {
            if(EditorApplication.isPlaying) {EditorUtility.DisplayDialog("DUOVEX", "Exit Play Mode first.", "OK");return;}
            var referenced=ReferencedAssets();
            var targets=Candidates.Where(p=>AssetDatabase.LoadMainAssetAtPath(p)!=null&&!referenced.Contains(p)).ToArray();
            if(targets.Length==0) {EditorUtility.DisplayDialog("DUOVEX", "No safe legacy assets to remove.", "OK");return;}
            if(!EditorUtility.DisplayDialog("DUOVEX Legacy Cleanup", "Back up and remove "+targets.Length+" unused legacy UI PNGs?\n\nFiles referenced from saved scenes, prefabs, or other assets are skipped.\nThe backup will be outside the Assets folder.", "Back Up & Remove", "Cancel"))return;
            string root=Path.GetFullPath(Path.Combine(Application.dataPath,".."));
            string backup=Path.Combine(root,"DUOVEX_LegacyBackup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(backup);
            int done=0;
            foreach(string path in targets)
            {
                string original=Path.Combine(root,path.Replace('/',Path.DirectorySeparatorChar));
                if(!File.Exists(original))continue;
                string dest=Path.Combine(backup,path.Replace('/',Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(dest));
                File.Copy(original,dest,true);
                if(File.Exists(original+".meta"))File.Copy(original+".meta",dest+".meta",true);
                if(AssetDatabase.DeleteAsset(path))done++;
                else Debug.LogError("[DUOVEX] Could not remove "+path+"; backup exists in "+backup);
            }
            AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("DUOVEX Legacy Cleanup", "Removed "+done+" unused PNGs.\nBackup: "+backup+"\n\nCustom scripts loading old Resources assets at runtime cannot be detected automatically: restore from backup if you have such scripts.", "OK");
            Debug.Log("[DUOVEX] Cleanup: "+done+" removed; backup at "+backup);
        }
    }
}
#endif
