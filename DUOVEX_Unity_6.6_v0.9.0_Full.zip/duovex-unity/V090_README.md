# DUOVEX v0.9.0 / Pause & UI quality update

## Changes

- In Gameplay, press ESC or Space to pause. Click SETTINGS to access music/hit-sound volume and note speed. BACK/Escape returns to the paused game **without resetting audio position, chart, combo or score**.
- RESUME shows only **3, 2, 1** in the center over the stopped notes; the large panel and blackout are gone. During this period gameplay and audio stay paused. ESC cancels the count-in.
- Main buttons and general-purpose buttons use the new `Visual090` SpriteState art, preserving the trapezoid silhouette; the violet accent follows the angled left edge. Button hover/keyboard selection plays one short menu sound (`SFX/MenuHover90.wav`). Artist can replace the PNG in the Inspector or project.
- PERFECT is inclusive on **both sides ±50 milliseconds** of the chart timestamp; GREAT ±80ms, GOOD ±120ms, BAD ±160ms. Scoring is symmetric. Hit diagnostic F8 shows **signed Δt** to help troubleshoot input/display/audio latency. No judgement timing change or audio content change except negligible epsilon protection at exact thresholds.
- Tools > Duovex > Validate 50ms Symmetric Judgement v0.9.0 runs explicit symmetric boundary cases for ±50ms etc. This is a code-level test only; playback latency must still be checked with the user's hardware.

## Upgrade

1. **Back up the previous project** and close Unity before copying files.
2. Patch installation: merge `Assets` from the patch into the existing v0.8.85/Clean project. It adds new files and replaces four C# files (DualSyncGame, DuovexVisual, DuovexUIFactory, editor scene generator/importer). No audio track or chart assets are changed.
3. Unity 6.6 > `Tools > Duovex > Generate Editable UI Scene` creates `Assets/Scenes/DuovexV090_PauseUIAndTiming.unity`. Open that scene. Previous manual scene design is never overwritten.
4. Run `Tools > Duovex > Validate 50ms Symmetric Judgement v0.9.0`, then play test pause/settings/back/countdown and `F8` diagnostic.
5. Dynamic `Main.unity` still uses current build code but previously generated serialized UI scenes will not automatically update. Generate and open the new v0.9 scene.

### Known limitations

- The assistant could not compile or play this version in Unity Editor. Unity import and actual interaction need testing on the user's machine.
- Timing debugger shows when Unity received input, **not** a measurement of keyboard hardware or display/driver latency.
- Existing game audio tracks and charts are unchanged. No assertion that the saved charts are perfectly synced to original mastered music.
