using UnityEngine;

namespace DualSync
{
    /// <summary>Signed timing error in seconds; early and late use identical cutoffs.</summary>
    public static class DuovexJudgeWindow90
    {
        // 0 PERFECT, 1 GREAT, 2 GOOD, 3 BAD, 4 MISS
        public static int Bucket(float signedErrorSeconds)
        {
            float absoluteMs=Mathf.Abs(signedErrorSeconds)*1000f;
            // Tiny floating-point guard, less than 0.001 ms.
            if(absoluteMs <= 50.0001f)return 0;
            if(absoluteMs <= 80.0001f)return 1;
            if(absoluteMs <= 120.0001f)return 2;
            if(absoluteMs <= 160.0001f)return 3;
            return 4;
        }
    }
}
