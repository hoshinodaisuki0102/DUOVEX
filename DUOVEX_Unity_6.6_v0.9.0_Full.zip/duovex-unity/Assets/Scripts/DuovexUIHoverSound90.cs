using UnityEngine;
using UnityEngine.EventSystems;

namespace DualSync
{
    /// <summary>UI-only hover sound; uses one shared AudioSource per UI canvas.</summary>
    [DisallowMultipleComponent]
    public sealed class DuovexUIHoverSound90 : MonoBehaviour, IPointerEnterHandler, ISelectHandler
    {
        static AudioSource sharedSource;
        static AudioClip hoverClip;
        static float lastPlayed=-10f;
        void PlayHover()
        {
            if(Time.unscaledTime < .25f || Time.unscaledTime-lastPlayed < .07f)return;
            if(hoverClip==null)hoverClip=Resources.Load<AudioClip>("SFX/MenuHover90");
            if(hoverClip==null)return;
            var canvas=GetComponentInParent<Canvas>();
            if(canvas==null)return;
            if(sharedSource==null || sharedSource.gameObject!=canvas.gameObject)
            {
                sharedSource=canvas.GetComponent<AudioSource>();
                if(sharedSource==null)sharedSource=canvas.gameObject.AddComponent<AudioSource>();
                sharedSource.playOnAwake=false;
                sharedSource.spatialBlend=0f;
            }
            lastPlayed=Time.unscaledTime;
            float sfx=PlayerPrefs.GetFloat("DUOVEX.HitSoundVolume",.32f);
            sharedSource.PlayOneShot(hoverClip,.17f*Mathf.Clamp01(sfx/.32f));
        }
        public void OnPointerEnter(PointerEventData e) { PlayHover(); }
        public void OnSelect(BaseEventData e) { PlayHover(); }
    }
}
