#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace DualSync.Editor
{
    public static class DuovexJudgementValidator90
    {
        [MenuItem("Tools/Duovex/Validate 50ms Symmetric Judgement v0.9.0")]
        static void Run()
        {
            int checkedCount=0;
            float[] millis={0f,20f,49.9f,50f,50.1f,79.9f,80.1f,119.9f,120.1f,159.9f,160.1f,200f};
            int[] expected={0,0,0,0,1,1,2,2,3,3,4,4};
            for(int i=0;i<millis.Length;i++)
                foreach(int sign in new[]{-1,1})
                {
                    float delta=sign*millis[i]/1000f;
                    int actual=DuovexJudgeWindow90.Bucket(delta);
                    if(actual!=expected[i])
                    {
                        string message=$"FAILED {sign*millis[i]:0.0}ms: expected {expected[i]}, received {actual}";
                        Debug.LogError(message);EditorUtility.DisplayDialog("DUOVEX timing",message,"OK");return;
                    }
                    checkedCount++;
                }
            // Both visual and hit logic must reference BeatToSeconds().
            Debug.Log($"DUOVEX v0.9.0: PASS {checkedCount} timing boundaries, FAST/SLOW symmetric; PERFECT [-50,+50] ms. F8 during play shows actual signed hit delta.");
            EditorUtility.DisplayDialog("DUOVEX timing",$"PASS: {checkedCount} early/late boundary tests. PERFECT is ±50ms on both sides.\nPress F8 during play for a live signed timing diagnostic.\nDevice/display/audio latency still requires on-device calibration.","OK");
        }
    }
}
#endif
